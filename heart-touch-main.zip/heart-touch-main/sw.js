self.addEventListener('push', function(event) {
    let payloadText = '';

    if (event.data) {
        try {
            const data = event.data.json();
            payloadText = data.message || data.title || event.data.text();
        } catch(e) {
            payloadText = event.data.text();
        }
    }

    if (payloadText.includes('START')) {
        const options = {
            body: 'الشريك يلمسك الآن! ❤️',
            icon: 'https://via.placeholder.com/128/ff416c/ffffff?text=Heart',
            vibrate: [500, 110, 500, 110, 450, 110, 200, 110, 450],
            tag: 'heart-touch-active',
            renotify: true
        };

        event.waitUntil(
            self.registration.showNotification('لمسة حب ❤️', options)
        );
    } 
    else if (payloadText.includes('STOP')) {
        event.waitUntil(
            self.registration.getNotifications({ tag: 'heart-touch-active' }).then(notifications => {
                notifications.forEach(notification => notification.close());
            })
        );
    }
});

self.addEventListener('notificationclick', function(event) {
    event.notification.close();
    event.waitUntil(
        clients.openWindow('/')
    );
});
